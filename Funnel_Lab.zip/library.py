"""Persistent candidate/run hierarchy. Short SQLite transactions suit local OneDrive use."""
import hashlib
import json
import sqlite3
import time
from pathlib import Path
from dataclasses import asdict
from physics import summarize

def encode(value): return json.dumps(value,sort_keys=True,separators=(',',':'))
def key(value): return hashlib.sha256(encode(value).encode()).hexdigest()[:24]
def passed(r): return not r['jam']
def metrics(results):
    s=summarize(results)
    s['passed']=sum(passed(r) for r in results)
    s['pass_rate']=s['passed']/max(1,s['cases'])
    s['delivery_rate']=s['fed']/max(1,s['total'])
    s['mean_time']=sum(r['elapsed'] for r in results)/max(1,len(results))
    s['mean_stall']=sum(r['max_stall'] for r in results)/max(1,len(results))
    return s
def ranking(s):
    # User objective: misses and delivery percentage do NOT affect selection.
    return (-s['pass_rate'],s['mean_stall'])

class Library:
    def __init__(self,path,read_only=False):
        self.path=Path(path).resolve(); self.read_only=read_only
        if read_only and self.path.exists():
            self.db=sqlite3.connect(self.path.as_uri()+'?mode=ro',uri=True,timeout=15)
            self.db.row_factory=sqlite3.Row
            self.db.execute('PRAGMA query_only=ON')
            return
        if not read_only: self.path.parent.mkdir(parents=True,exist_ok=True)
        self.db=sqlite3.connect(':memory:' if read_only else self.path,timeout=15)
        self.db.row_factory=sqlite3.Row
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS candidates(
          id TEXT PRIMARY KEY, name TEXT, geometry TEXT, settings TEXT, session TEXT,
          stage TEXT, created REAL, starred INTEGER DEFAULT 0, auto_star INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS runs(
          id INTEGER PRIMARY KEY, candidate TEXT REFERENCES candidates(id), label TEXT,
          cases TEXT, expected INTEGER, status TEXT, summary TEXT, UNIQUE(candidate,label));
        CREATE TABLE IF NOT EXISTS results(
          run INTEGER REFERENCES runs(id), case_key TEXT, payload TEXT,
          PRIMARY KEY(run,case_key));
        CREATE TABLE IF NOT EXISTS sessions(
          id TEXT PRIMARY KEY, config TEXT, baseline TEXT, state TEXT, status TEXT, created REAL);
        CREATE TABLE IF NOT EXISTS controls(session TEXT PRIMARY KEY, pause INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS progress(session TEXT PRIMARY KEY, payload TEXT);
        CREATE TABLE IF NOT EXISTS saved_tests(
          id TEXT PRIMARY KEY,name TEXT,case_data TEXT,source_session TEXT,
          rank INTEGER,failures INTEGER,attempts INTEGER,settings TEXT,created REAL);
        CREATE TABLE IF NOT EXISTS training_votes(
          session TEXT, candidate TEXT, case_key TEXT, case_data TEXT, jam INTEGER, missed INTEGER,
          PRIMARY KEY(session,candidate,case_key));
        CREATE INDEX IF NOT EXISTS votes_session_case ON training_votes(session,case_key);
        CREATE INDEX IF NOT EXISTS candidates_session ON candidates(session);
        CREATE INDEX IF NOT EXISTS runs_candidate ON runs(candidate);
        ''')
        self.db.commit()
        if read_only:
            self.db.execute('PRAGMA query_only=ON')
            return
        if not self.db.execute('SELECT 1 FROM training_votes LIMIT 1').fetchone():
            with self.db:
                self.db.execute('''INSERT OR IGNORE INTO training_votes
                  SELECT c.session,c.id,t.case_key,json_extract(t.payload,'$.case'),
                         json_extract(t.payload,'$.jam'),json_extract(t.payload,'$.missed')
                  FROM results t JOIN runs r ON t.run=r.id JOIN candidates c ON c.id=r.candidate
                  WHERE c.session<>'' AND (r.label LIKE 'Broad survey%' OR r.label LIKE 'Focus %')''')
    def close(self): self.db.close()
    def clear_history(self,mode='unstarred'):
        """Delete selected history, invalidate checkpoints, and reclaim disk space."""
        if mode not in ('unstarred','starred','all'): raise ValueError('Unknown cleanup mode')
        if self.read_only: raise RuntimeError('Cleanup requires a writable connection.')
        from adaptive import acquire_session_lock
        leases=[]
        try:
            self.db.execute('BEGIN IMMEDIATE')
            for row in self.sessions():
                try: leases.append(acquire_session_lock(self.path,row['id']))
                except RuntimeError:
                    raise RuntimeError('Pause the trainer before clearing history (train.cmd pause).') from None
            where={'unstarred':'NOT (starred OR auto_star)','starred':'(starred OR auto_star)','all':'1'}[mode]
            count=self.db.execute('SELECT COUNT(*) FROM candidates WHERE '+where).fetchone()[0]
            self.db.execute('DELETE FROM results WHERE run IN (SELECT r.id FROM runs r JOIN candidates c ON c.id=r.candidate WHERE '+where+')')
            self.db.execute('DELETE FROM runs WHERE candidate IN (SELECT id FROM candidates WHERE '+where+')')
            self.db.execute('DELETE FROM candidates WHERE '+where)
            # Checkpoints reference removed candidate IDs and must never resume.
            for table in ('training_votes','controls','progress','sessions'): self.db.execute('DELETE FROM '+table)
            self.db.execute("UPDATE candidates SET session=''")
            self.db.commit()
        except Exception:
            self.db.rollback(); raise
        finally:
            for lease in leases: lease.close()
        self.db.execute('VACUUM')
        return count
    def candidate(self,cid):
        row=self.db.execute('SELECT * FROM candidates WHERE id=?',(cid,)).fetchone()
        if not row: return None
        out=dict(row)
        for k in ['geometry','settings']: out[k]=json.loads(out[k])
        return out
    def add(self,name,geometry,settings,session='',stage='Manual',cid=None):
        cid=cid or key([name,geometry,settings,time.time_ns()])
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO candidates(id,name,geometry,settings,session,stage,created) VALUES(?,?,?,?,?,?,?)',
                            (cid,name,encode(geometry),encode(settings),session,stage,time.time()))
        return cid
    def candidates(self):
        rows=self.db.execute('SELECT * FROM candidates ORDER BY (starred OR auto_star) DESC,created DESC').fetchall()
        return [dict(r) for r in rows]
    def candidate_scores(self):
        """Read saved summaries only; never rescan simulation payloads for sorting."""
        rows=self.db.execute('''WITH scored AS (
          SELECT candidate,label,summary,
            ROW_NUMBER() OVER (PARTITION BY candidate ORDER BY
              CASE WHEN label='Fresh validation' THEN 0
                   WHEN label='Finalist screening' THEN 1
                   WHEN label='Broad survey' THEN 2
                   WHEN instr(label,' · screen ')=0 THEN 3 ELSE 4 END,
              expected DESC,id DESC) AS preference
          FROM runs WHERE status IN ('complete','screened out') AND expected>0 AND label NOT LIKE 'Retest %'
            AND json_extract(summary,'$.cases')=expected)
          SELECT candidate,label,summary FROM scored WHERE preference=1''')
        scores={}
        for row in rows:
            summary=json.loads(row['summary'])
            scores[row['candidate']]={'pass_rate':summary['pass_rate'],'mean_stall':summary['mean_stall'],
                                      'label':row['label'],'validated':row['label']=='Fresh validation'}
        return scores
    def star(self,cid):
        with self.db: self.db.execute('UPDATE candidates SET starred=1-starred WHERE id=?',(cid,))
    def run(self,cid,label,cases):
        serial=[asdict(c) if hasattr(c,'__dataclass_fields__') else c for c in cases]
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO runs(candidate,label,cases,expected,status) VALUES(?,?,?,?,?)',
                            (cid,label,encode(serial),len(serial),'pending'))
        row=dict(self.db.execute('SELECT * FROM runs WHERE candidate=? AND label=?',(cid,label)).fetchone())
        if json.loads(row['cases'])!=serial: raise ValueError('A saved run cannot change its test set.')
        return row
    def runs(self,cid):
        return [dict(r) for r in self.db.execute('SELECT * FROM runs WHERE candidate=? ORDER BY id DESC',(cid,))]
    def results(self,run_id):
        return [json.loads(r[0]) for r in self.db.execute('SELECT payload FROM results WHERE run=? ORDER BY rowid',(run_id,))]
    def cache(self,cid,full=True,case_keys=None):
        # Filter before decoding and deduplicate repeated run payloads in SQL.
        query='SELECT t.case_key,t.payload FROM results t JOIN runs r ON t.run=r.id WHERE r.candidate=?'
        params=[cid]
        if full: query+=" AND COALESCE(json_extract(t.payload,'$.censored'),0)=0"
        if case_keys is not None:
            if not case_keys: return {}
            query+=' AND t.case_key IN ('+','.join('?' for _ in case_keys)+')'; params.extend(case_keys)
        query+=' GROUP BY t.case_key'
        return {r[0]:json.loads(r[1]) for r in self.db.execute(query,params)}
    def save_results(self,run_id,results):
        with self.db:
            self.db.executemany('INSERT OR REPLACE INTO results VALUES(?,?,?)',[(run_id,key(r['case']),encode(r)) for r in results])
            run=self.db.execute('SELECT r.label,c.id,c.session FROM runs r JOIN candidates c ON c.id=r.candidate WHERE r.id=?',(run_id,)).fetchone()
            if run['session'] and (run['label'].startswith('Broad survey') or run['label'].startswith('Focus ')):
                self.db.executemany('INSERT OR REPLACE INTO training_votes VALUES(?,?,?,?,?,?)',
                  [(run['session'],run['id'],key(r['case']),encode(r['case']),int(r['jam']),r['missed']) for r in results])
            actual=self.results(run_id)
            expected=self.db.execute('SELECT expected FROM runs WHERE id=?',(run_id,)).fetchone()[0]
            status='complete' if len(actual)==expected else 'partial'
            self.db.execute('UPDATE runs SET status=?,summary=? WHERE id=?',(status,encode(metrics(actual)),run_id))
        return status
    def state(self,sid):
        row=dict(self.db.execute('SELECT * FROM sessions WHERE id=?',(sid,)).fetchone())
        for k in ['config','state']: row[k]=json.loads(row[k])
        return row
    def save_state(self,sid,state,status='running'):
        with self.db: self.db.execute('UPDATE sessions SET state=?,status=? WHERE id=?',(encode(state),status,sid))
    def sessions(self): return [dict(r) for r in self.db.execute('SELECT * FROM sessions ORDER BY created DESC')]
    def request_pause(self,sid,value=True):
        with self.db: self.db.execute('INSERT OR REPLACE INTO controls VALUES(?,?)',(sid,int(value)))
    def pause_requested(self,sid):
        row=self.db.execute('SELECT pause FROM controls WHERE session=?',(sid,)).fetchone()
        return bool(row and row[0])
    def save_progress(self,sid,payload):
        with self.db: self.db.execute('INSERT OR REPLACE INTO progress VALUES(?,?)',(sid,encode(payload)))
    def progress(self,sid):
        try: row=self.db.execute('SELECT payload FROM progress WHERE session=?',(sid,)).fetchone()
        except sqlite3.OperationalError: return {}
        return json.loads(row[0]) if row else {}
    def hardness(self,sid):
        # Each geometry votes once per case, even when a cache is reused across rounds.
        rows=self.db.execute('''SELECT case_key,case_data,COUNT(*) attempts,SUM(jam) failures,
          SUM(missed>0) misses FROM training_votes WHERE session=? GROUP BY case_key''',(sid,))
        stats=[{'key':r['case_key'],'case':json.loads(r['case_data']),'attempts':r['attempts'],
                'failures':r['failures'],'jams':r['failures'],'misses':r['misses'],
                'rate':r['failures']/r['attempts']} for r in rows]
        return sorted(stats,key=lambda s:(-s['rate'],-s['failures'],s['key']))
    def saved_tests(self):
        if not self.db.execute("SELECT 1 FROM sqlite_master WHERE name='saved_tests'").fetchone(): return []
        out=[]
        for row in self.db.execute('SELECT * FROM saved_tests ORDER BY created DESC,source_session,rank,id'):
            item=dict(row); item['case']=json.loads(item.pop('case_data')); item['settings']=json.loads(item['settings'])
            out.append(item)
        return out
    def save_hard_tests(self,sid):
        """Keep five deduplicated highest jam-rate training cases per session."""
        session=self.state(sid); candidate=self.candidate(session['baseline'])
        hard=[r for r in self.hardness(sid) if r['failures']>0][:5]; now=time.time()
        with self.db:
            self.db.execute('DELETE FROM saved_tests WHERE source_session=?',(sid,))
            for rank,row in enumerate(hard,1):
                self.db.execute('INSERT INTO saved_tests VALUES(?,?,?,?,?,?,?,?,?)',
                  ('hard-'+sid+'-'+row['key'],f'Hard case #{rank}',encode(row['case']),sid,rank,
                   row['failures'],row['attempts'],encode(candidate['settings']),now))
        return len(hard)
    def save_test(self,name,case,settings):
        cid='custom-'+key([case,time.time_ns()])
        with self.db:
            self.db.execute('INSERT INTO saved_tests VALUES(?,?,?,?,?,?,?,?,?)',
              (cid,name,encode(case),'',0,0,0,encode(settings),time.time()))
        return cid
    def import_legacy(self,folder):
        folder=Path(folder)
        baseline=folder/'validation_report.json'
        if baseline.exists():
            d=json.loads(baseline.read_text()); cid=self.add('Original CAD',d['geometry'],d['settings'],stage='Imported',cid='original-cad')
            run=self.run(cid,'Original 137-case baseline',[r['case'] for r in d['baseline_results']]); self.save_results(run['id'],d['baseline_results'])
        for filename in ['verified_search.json','latest_search.json']:
            p=folder/filename
            if not p.exists(): continue
            d=json.loads(p.read_text())
            if not d.get('best_geometry') or not d.get('validation_results'): continue
            cid=self.add('Earlier search candidate',d['best_geometry'],d['settings'],stage='Imported',cid='legacy-'+key(d['best_geometry']))
            run=self.run(cid,'Earlier holdout',[r['case'] for r in d['validation_results']]); self.save_results(run['id'],d['validation_results'])
